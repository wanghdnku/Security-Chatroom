package com.ds.proj2;
import org.json.*;

public class JSONCreater {

	public static JSONObject JSONencoder(String str) throws JSONException {
		JSONObject obj = new JSONObject();
		if (str.charAt(0) != '#') {
			obj.put("type", "message");
			obj.put("content", str);
		} else {
			String[] parameters = (str + " 0 0 0").split(" ");
			switch (parameters[0]) {
				case "#register": {
					obj.put("type", "register");
					obj.put("username", parameters[1]);
					obj.put("password", parameters[2]);
					break;
				}
				case "#login": {
					obj.put("type", "login");
					obj.put("username", parameters[1]);
					obj.put("password", parameters[2]);
					break;
				}
				
				case "#identitychange": {
					obj.put("type", "identitychange");
					obj.put("identity", parameters[1]);
					break;
				}
				case "#join": {
					obj.put("type", "join");
					obj.put("roomid", parameters[1]);
					break;
				}
				case "#list": {
					obj.put("type", "list");
					break;
				}
				case "#who": {
					obj.put("type", "who");
					obj.put("roomid", parameters[1]);
					break;
				}
				case "#createroom": {
					obj.put("type", "createroom");
					obj.put("roomid", parameters[1]);
					break;
				}
				case "#kick": {
					obj.put("type", "kick");
					obj.put("roomid", parameters[1]);
					obj.put("time", Integer.parseInt(parameters[2]));
					obj.put("identity", parameters[3]);
					break;
				}
				case "#delete": {
					obj.put("type", "delete");
					obj.put("roomid", parameters[1]);
					break;
				}
				case "#quit": {
					obj.put("type", "quit");
					break;
				}
				default: {
					obj.put("type", "invalid");
				}
			}
		}
		return obj;
	}
	
}
