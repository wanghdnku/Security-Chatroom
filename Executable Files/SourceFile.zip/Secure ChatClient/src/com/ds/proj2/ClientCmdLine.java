package com.ds.proj2;
import org.kohsuke.args4j.*;

public class ClientCmdLine {
	
	@Argument(required = false, index = 0, usage = "Host Address")
	private String host = "localhost";
	
	// Give it a default value of 4444 sec
	@Option(required = false, name = "-p", aliases = {"--port"}, usage = "Port Address")
	private int port = 4444;
	
	@Option(required = true, name = "-keystore", aliases = {"--keystore"}, usage = "Keystore Path")
	private String certPath;
	
	@Option(required = false, name = "-storepass", aliases = {"--password"}, usage = "Keystore Password")
	private String password = "comp90015";
	

	public String getStorePass() {
		return password;
	}
	
	public String getPath() {
		return certPath;
	}
	
	public int getPort() {
		return port;
	}

	public String getHost() {
		return host;
	}
	
}
