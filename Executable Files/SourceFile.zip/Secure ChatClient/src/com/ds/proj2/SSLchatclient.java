package com.ds.proj2;

import java.io.*;
import java.net.*;
import java.security.KeyStore;
//import java.security.interfaces.*;
import javax.net.ssl.*;
//import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;



public class SSLchatclient {

	private static String guestId = "guest";
	public static String roomId = "MainHall";
	//private static RSAPublicKey rsaPublicKey;
	
	
	public static void main(String[] args) {
		try {

			int port = 4444;
			String host = "localhost";
			ClientCmdLine arguments = new ClientCmdLine();
			CmdLineParser parser = new CmdLineParser(arguments);
			
			KeyStore keyStore = KeyStore.getInstance("JCEKS");
			String keyStorePath = "Files/chatkeystore.jceks";
			//String keyStorePath = "/Users/hayden/Desktop/keytool/chatkeystore.jceks";
			String keyStorePassword = "comp90015";
			
			try{
				// parse the command line options with the args4j library
				parser.parseArgument(args);
				// print values of the command line options
				host = arguments.getHost();
				port = arguments.getPort();
				keyStorePath = arguments.getPath();
				keyStorePassword = arguments.getStorePass();
			} catch (CmdLineException e) {
				System.err.println(e.getMessage());
				parser.printUsage(System.err);
				System.exit(-1);
			}
			
		
			
			System.setProperty("javax.net.ssl.trustStore", keyStorePath);
			System.setProperty("javax.net.ssl.trustStorePassword", keyStorePassword); 
			SSLSocketFactory sslsf = (SSLSocketFactory) SSLSocketFactory.getDefault();
			

			keyStore.load(new FileInputStream(keyStorePath), keyStorePassword.toCharArray());
			// Get the certificate.
			//java.security.cert.Certificate cert = keyStore.getCertificate("chatkey");
			// Get the public key.
			//rsaPublicKey = (RSAPublicKey)cert.getPublicKey();
			//System.out.println("Got the public key from certificate!");
			//System.out.println("Public Key : " + Base64.encodeBase64String(rsaPublicKey.getEncoded()));
			
			System.out.println("--------------------------------------------");
			
			Socket socket = sslsf.createSocket(host, port);

			// Command thread: get command from input stream.
			Thread commandThread = new Thread(new sendCommand(socket));
			commandThread.start();
			
			// Response thread: read response from server.
			Thread responseThread = new Thread(new receiveResponse(socket));
			responseThread.start();
			
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.exit(-1);
		}
	}
	
	


	/**********************************************************************
	 * The thread that get command line from console and send it to server.
	 **********************************************************************/
	static class sendCommand implements Runnable {
		
		// The socket that connect with the server.
		private Socket socket;

		// The constructor.
		public sendCommand(Socket socket) {
			this.socket = socket;
		}

		@Override
		public void run() {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);
				String msg;

				boolean runningFlag = true;
				while (runningFlag) {
					
					// Read a string command from console.
					msg = br.readLine();
					String cmd = msg;
					if (!cmd.equals("")) {
						// pack the massage as JSON object.
						msg = JSONCreater.JSONencoder(msg).toString();
						// Send the message to server.
						pw.println(msg);
					}
					if (cmd.equals("#quit")) {
						//pw.close();
						//br.close();
						runningFlag = false;
						//exec.shutdownNow();
						break;
					}
				}
								
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
	}
	
	
	/*****************************************************************
	 * The thread which receive response from server and deal with it.
	 *****************************************************************/
	static class receiveResponse implements Runnable {

		// The socket that connect with the server.
		private Socket socket;
		
		// The constructor.
		public receiveResponse(Socket socket) {
			this.socket = socket;
		}
		
		@Override
		public void run() {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				String server_msg = "";
				// Reads the information from server.
				boolean runningFlag = true;
				while (((server_msg = br.readLine()) != null) && runningFlag) {
					
					// The function 'processResponse' deal with the response from server, and print out message at client.
					processResponse(server_msg);
					//System.out.println(server_msg);
					
					
					
					JSONObject obj = new JSONObject(server_msg);
					String type = obj.getString("type");
					if (type.equals("message")) {
						if (obj.getString("content").equals("Disconnected from server.")) {
							runningFlag = false;
							System.exit(0);
						}
					}
					
					
				} // while circulation ends.
								
			} catch (IOException e) {
				e.printStackTrace();
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}
		
	}
	
	
	/*******************************************************************
	 * This function receive a JSON string and read information from it.
	 *******************************************************************/
	public static void processResponse (String resp) throws JSONException {
		JSONObject response = new JSONObject(resp);
		String type = response.getString("type");
		switch (type) {
		
		
			case "newidentity": {
				String former = response.getString("former");
				String identity = response.getString("identity");
				if (former.equals("")) {
					System.out.println("Connected to server as " + identity + ".");
					guestId = identity;
				} else if (former.equals(identity)) {
					System.out.print("Identity is not change: ");
				} else {
					
					
					if (!identity.equals(guestId))
						System.out.println();
					
					
					// Print the information that someone change the id.
					System.out.println(former + " is now " + identity + "!");
					// If it is the client itself change the id, then update the information saved in the client.
					if (former.equals(guestId)) {
						//formerId = guestId;
						guestId = identity;
					}
				}
				break;
			} // case "newidentity" ends.
			
			case "roomcontents": {
				String roomId = response.getString("roomid");
				JSONArray identities = response.getJSONArray("identities");
				String roomOwner = response.getString("owner");
				
				System.out.print(roomId + " contains ");
				for (int i=0; i<identities.length(); i++) {
					System.out.print(identities.get(i));
					if (roomOwner.equals(identities.get(i))) {
						System.out.print("* ");
					} else {
						System.out.print(" ");
					}
				}
				System.out.println();
				break;
			} // case "roomcontents" ends.
			
			case "roomchange": {
				// Receive the information from JSON object.
				String guest = response.getString("identity");
				String formerRoom = response.getString("former");
				String currentRoom = response.getString("roomid");
				
				if (currentRoom.equals("")) {
					// currentRoom is null means the user is quit.
					
					if (!guest.equals(guestId))
						System.out.println();
					
					System.out.println(guest + " leaves " + formerRoom);
				} else {
					
					if (formerRoom.equals(currentRoom)) {
						System.out.print("Room is not change: ");
					} else {
						
						if (!guest.equals(guestId))
							System.out.println();
						
						
						if (formerRoom.equals("")) {
							System.out.println(guest + " moves to " + currentRoom);
						} else {
							System.out.println(guest + " moves from " + formerRoom + " to " + currentRoom); 
						}
					}
				} // if..else ends.
				break;
			} // case "roomchange" ends.
			
			case "roomlist": {
				// Just list the current rooms.
				JSONArray rl = response.getJSONArray("rooms");
				JSONObject jo = new JSONObject();
				for (int i=0; i<rl.length(); i++) {
					jo = rl.getJSONObject(i);
					System.out.print(jo.getString("roomid") + ": ");
					System.out.println(jo.getInt("count"));
				}
				break;
			} // case "roomlist" ends.
			
			case "message": {
				String identity = response.getString("identity");
				String content = response.getString("content");
				if (identity.equals("#Server")) {
					// If the identity of this message is "!!!!", it means it is a server message.
					System.out.println(content);
				} else if (identity.equals(">console")) {
					// If the identity of this message is ">>>>", it is needed to print a console message.
					System.out.print(content);
				} else {
					// In this case, the message is from users.
					
					
					if (!identity.equals(guestId)) {
						System.out.println();
					}
					
					
					System.out.println(identity + ": " + content);
				}
				break;
			} // case "message" ends.
			
		} // switch..case ends.
		
	} // 'processResponse' ends.
	
	
	
	
}

