package com.ds.proj2;
/***********
 * Class: ClientRSA.java
 * Function:
 */



import java.security.*;
import java.security.interfaces.*;
import java.security.spec.*;
import javax.crypto.Cipher;
import org.apache.commons.codec.binary.Base64;


public class ClientSecurity {

	
	/**
	 * @function publicEncoder
	 * @param src
	 * @param rsaPublicKey
	 * @return encodedText
	 * This function takes a text and return a encoded text with RSA algorithm.
	 */
	public static String publicEncoder(String src, RSAPublicKey rsaPublicKey) throws Exception {
		// Encode using public key.
		X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(rsaPublicKey.getEncoded());
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] pubEncodedByte = cipher.doFinal(src.getBytes());
		//System.out.println("Public Encoding: " + Base64.encodeBase64String(pubEncodedByte));
		
		String pubEncodedString = Base64.encodeBase64String(pubEncodedByte);
		return pubEncodedString;
		//return pubEncodedByte;
	} // publicEncoder ends.
	
	
	public static String publicDecoder(String priEncodedString, RSAPublicKey rsaPublicKey) throws Exception {
		// Decode using public key.
		
		byte[] priEncodedByte = Base64.decodeBase64(priEncodedString);
		
		X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(rsaPublicKey.getEncoded());
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, publicKey);
		byte[] pubDecodedByte = cipher.doFinal(priEncodedByte);
		//System.out.println("Public Decoding: " + new String(pubDecodedByte));
		return new String(pubDecodedByte);
	} // publicDecoder ends.
	
} // ClientRSA ends.
