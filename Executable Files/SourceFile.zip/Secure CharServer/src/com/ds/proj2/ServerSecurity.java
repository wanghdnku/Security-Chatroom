package com.ds.proj2;

import java.security.*;
import java.security.interfaces.*;
import java.security.spec.*;
import javax.crypto.Cipher;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.codec.binary.Base64;


public class ServerSecurity {
	
	public static String pbeEncoder(String src, byte[] salt, Key key) throws Exception {
		
		PBEParameterSpec pbeParameterSpec = new PBEParameterSpec(salt, 10);
		Cipher cipher = Cipher.getInstance("PBEWITHMD5andDES");
		cipher.init(Cipher.ENCRYPT_MODE, key, pbeParameterSpec);
		byte[] pbeEncodedByte = cipher.doFinal(src.getBytes());
		//System.out.println("JDK PBE encrypt: " + Base64.encodeBase64String(pbeEncodedByte));
		
		String pbeEncodedString = Base64.encodeBase64String(pbeEncodedByte);
		return pbeEncodedString;
	}
	
	
	public static String pbeDecoder(String src, byte[] salt, Key key) throws Exception {
		
		byte[] pbeEncodedByte = Base64.decodeBase64(src);
		PBEParameterSpec pbeParameterSpec = new PBEParameterSpec(salt, 10);
		Cipher cipher = Cipher.getInstance("PBEWITHMD5andDES");
		cipher.init(Cipher.DECRYPT_MODE, key, pbeParameterSpec);
		byte[] pbeDecodedByte = cipher.doFinal(pbeEncodedByte);
		//System.out.println("JDK PBE decrypt: " + new String(pbeDecodedByte));
		return new String(pbeDecodedByte);
	}
	
	
	
	
	
	public static String privateEncoder(String src, RSAPrivateKey rsaPrivateKey) throws Exception {
		// Encode using private key.
		PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(rsaPrivateKey.getEncoded());
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, privateKey);
		byte[] priEncodedByte = cipher.doFinal(src.getBytes());
		//System.out.println("私钥加密: " + Base64.encodeBase64String(priEncodedByte));
		
		String priEncodedString = Base64.encodeBase64String(priEncodedByte);
		return priEncodedString;
		//return priEncodedByte;
	} // privateEncoder ends.

	
	public static String privateDecoder(String publicEncodedString, RSAPrivateKey rsaPrivateKey) throws Exception {
		// Decode using private key.
		
		byte[] pubEncodedByte = Base64.decodeBase64(publicEncodedString);
		
		PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(rsaPrivateKey.getEncoded());
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] priDecodedByte = cipher.doFinal(pubEncodedByte);
		//System.out.println("私钥解密: " + new String(priDecodedByte));
		return new String(priDecodedByte);
	} // privateDecoder ends.
	
} // ServerRSA ends.
