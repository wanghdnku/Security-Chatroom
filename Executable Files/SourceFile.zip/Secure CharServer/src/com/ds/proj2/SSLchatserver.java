package com.ds.proj2;

import java.io.*;
//import java.net.*;
import java.security.*;
//import java.security.interfaces.*;
import java.text.ParseException;
import java.util.ArrayList;

//import java.security.spec.*;
//import javax.crypto.*;
import javax.net.ssl.*;
//import org.apache.commons.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;

public class SSLchatserver {
	
	// The Integer list 'guestName' is to store the  number that is used by guest names.
	private static ArrayList<Integer> guestName = new ArrayList<Integer>();
	// The Guest list 'guestList' is to store all the detail information of guests.
	private static ArrayList<Guest> guestList = new ArrayList<>();
	
	private static ArrayList<Room> roomList = new ArrayList<>();
	
	private static ArrayList<AuthenticatedGuest> registeredList = new ArrayList<>();
		
	// The object of ServerSocket.
	private static SSLServerSocket sslServerSocket;
	//private static RSAPrivateKey rsaPrivateKey;
	
	
	public static void main(String[] args) {
		
		int port = 4444;
		String keyStorePath = "Files/chatkeystore.jceks";
		//String keyStorePath = "/Users/hayden/Desktop/keytool/chatkeystore.jceks";
		String keyStorePassword = "comp90015";
		String privateKeyPassword = "123456";
		
		ServerCmdLine arguments = new ServerCmdLine();
		CmdLineParser parser = new CmdLineParser(arguments);
		try{
			// parse the command line options with the args4j library
			parser.parseArgument(args);
			// print values of the command line options
			port = arguments.getPort();
			keyStorePath = arguments.getPath();
			keyStorePassword = arguments.getStorePass();
			privateKeyPassword = arguments.getKeyPass();
			
		} catch (CmdLineException e) {
			System.err.println(e.getMessage());
			parser.printUsage(System.err);
			System.exit(-1);
		}
		

		
		
		try {
			KeyStore keyStore = KeyStore.getInstance("JCEKS");
			keyStore.load(new FileInputStream(keyStorePath), keyStorePassword.toCharArray());
			KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
			keyManagerFactory.init(keyStore, privateKeyPassword.toCharArray());
			SSLContext sslContext = SSLContext.getInstance("SSLv3");

			sslContext.init(keyManagerFactory.getKeyManagers(), null, null);
			
			//rsaPrivateKey = (RSAPrivateKey)keyStore.getKey("chatkey", "123456".toCharArray());
			//System.out.println("Private Key: " + Base64.encodeBase64String(rsaPrivateKey.getEncoded()));
			//System.out.println("Got the private key from certificate!");


			SSLServerSocketFactory sslssf = sslContext.getServerSocketFactory();
			
			sslServerSocket = (SSLServerSocket) sslssf.createServerSocket(port);
//			sslServerSocket = (SSLServerSocket) sslssf.createServerSocket();
//			SocketAddress socketAddress = new InetSocketAddress("localhost", port);
//			sslServerSocket.bind(socketAddress);
			System.out.println("--------------------------------------------");
			System.out.println("Server is now listening...");
			System.out.println("--------------------------------------------");
			roomList.add(new Room("MainHall", ""));
			
			
			
			SSLSocket sslSocket = null;
			
            while (true) {
                // Once a client wants to connect, the server accept the connection and save it.
            	sslSocket = (SSLSocket) sslServerSocket.accept();
                guestList.add(new Guest(initialName(), "", sslSocket));
                // Create a new thread for client.
                Thread clientThread = new Thread(new ChatThread(guestList.get(guestList.size()-1)));
                clientThread.start();
            }			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
			
	}
	
	
	/***********************************************************
	 * This is the thread that deals with one client connection.
	 ***********************************************************/
    static class ChatThread implements Runnable {
        
    	private Guest guest;
        private BufferedReader bufferedReader;
        private PrintWriter printWriter;

        // Constructor.
        public ChatThread(Guest guest) throws IOException {
            this.guest = guest;
            // bufferedReader is to receive the command from client.
            bufferedReader = new BufferedReader(new InputStreamReader(guest.socket.getInputStream()));
        }

        // run function in the ChatThread
        public void run() {
            
        	try {
        		System.out.println(guest.guestId + " connects to the system.");
        		CalcRoomList();
            	// When a new client is connected to the server, then do:
            	JSONObject ServerMessage = new JSONObject();
            	// First, send a NewIdentity message.
            	ServerMessage = JSONTools.NewIdentity("", guest.guestId);
            	guestMessage(guest.guestId, ServerMessage.toString());
            	// Second, send a RoomList message.
            	ServerMessage = JSONTools.RoomList(roomList);
            	guestMessage(guest.guestId, ServerMessage.toString());
            	// Third, send a RoomChange message.
            	ServerMessage = JSONTools.RoomChange(guest.guestId, "", "MainHall");
            	//guestMessage(guest.guestId, ServerMessage.toString());
            	overallMessage(ServerMessage.toString());
            	// Forth, send a RoomContent message.
            	ServerMessage = JSONTools.RoomContents("MainHall", guestList);
            	guestMessage(guest.guestId, ServerMessage.toString());            	
            	
				///////////////////////////////////////////////////////////////
				// Let the client print a message like "[MainHall] guest1> " //
				ServerMessage = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
				guestMessage(guest.guestId, ServerMessage.toString());
				///////////////////////////////////////////////////////////////
            	
            	// When the running flag is false, the thread will come to the end.
            	boolean runningFlag = true;
            	String command = "";
            	
            	// Running persistently until the running flag is false.
                while (( (command = bufferedReader.readLine()) != null) && runningFlag) {
	
                	// The command from client will be processed and responded here.
                	doResponse(command);
                	
                	// This is the exit of this thread.
                	JSONObject cmdObject = new JSONObject(command);
                	if(cmdObject.getString("type").equals("quit")) {
                		guestList.remove(guest);
                		runningFlag = false;
                		//bufferedReader.close();
                		//printWriter.close();
                		//guest.socket.close();
                	}
                	
                } // while loop ends.
                
        		//bufferedReader.close();
        		//printWriter.close();
                guest.socket.close();
                
                
            } catch (IOException | JSONException e) {
                System.out.println("Exception occurs.");
            	e.printStackTrace();
            	System.exit(-1);
            }
        }



        /**********************************************************
         * Receive and parse JSON string command, then do response.
         **********************************************************/
        public synchronized void doResponse (String cmd) throws JSONException {
        	// Change the JSON string to a JSON object.
        	JSONObject command = new JSONObject(cmd);
        	// This JSON object called 'response' store the feedback that will be sent back to client.
        	JSONObject response = new JSONObject();
        	// Get the type of command.
        	String type = command.getString("type");
        	// Each type command do different operation.
        	switch (type) {
        	
        	
        		case "register": {
        			String username = command.getString("username");
        			String password = command.getString("password");
        			if (!isRegistedId(guest.guestId)) {
        				guest.registered = true;
        				addAuthentication(username, password, guest.guestId);
						response = JSONTools.ServerMessage("#Server", "You are registered as username: " + username);
						guestMessage(guest.guestId, response.toString());
						
						System.out.println(guest.guestId + " register to chat system.");
        			} else {
						response = JSONTools.ServerMessage("#Server", "The username is in use, try other username!");
						guestMessage(guest.guestId, response.toString());
        			}
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
        			break;
        		}
        	
        		case "login": {
        			String username = command.getString("username");
        			String password = command.getString("password");
        			if (checkAuthentication(username, password)) {
						if (guest.guestId.contains("guest")) {
							// Release the number in the former identity, such as '1' in guest1.
							char a = guest.guestId.charAt(guest.guestId.length()-1);
							int idNum = Integer.parseInt(String.valueOf(a));
							guestName.remove((Integer)idNum);
						}
        				
        				guest.guestId = getAuthenticatedId(username);
        				guest.registered = true;
						response = JSONTools.ServerMessage("#Server", "Welcome back: " + guest.guestId);
						guestMessage(guest.guestId, response.toString());
						
						System.out.println("Authenticated user " + guest.guestId + " comes back.");
        			} else {
						response = JSONTools.ServerMessage("#Server", "Login fails, please register first!");
						guestMessage(guest.guestId, response.toString());
        			}
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
        			break;
        		}
        	
        		// When the client wants to change the identity.
	        	case "identitychange": {
					String newId = command.getString("identity");
					
					if (isValidId(newId)) {
						// The situation that the id is valid.
						if (isNotInuse(newId) && (!isRegistedId(newId))) {
							
							if (guest.guestId.contains("guest")) {
								// Release the number in the former identity, such as '1' in guest1.
								char a = guest.guestId.charAt(guest.guestId.length()-1);
								int idNum = Integer.parseInt(String.valueOf(a));
								guestName.remove((Integer)idNum);
							}
							// Change the information recorded in the roomList.
							//changeGuestInRoom(guest.guestId, newId, guest.room);
							// Change the ID and then sent NewIdentity message to all clients.
							
							if (guest.registered) {
								changeAuthenticatedId(guest.guestId, newId);
							}
							guest.formerId = guest.guestId;
							guest.guestId = newId;
							
							System.out.println(guest.formerId + " changes the identity.");
							
							response = JSONTools.NewIdentity(guest.formerId, newId);
							overallMessage(response.toString());
						} else {
							// If the Id is in use, then tell the client
							response = JSONTools.NewIdentity(guest.guestId, guest.guestId);
							guestMessage(guest.guestId, response.toString());
							response = JSONTools.ServerMessage("#Server", newId + " is now in use.");
							guestMessage(guest.guestId, response.toString());
						}
					} else {
						// The situation that the id is invalid.
						// If the NewIdentity is begin with '!', so the client know that is invalid.
						response = JSONTools.NewIdentity(guest.guestId, guest.guestId);
						// Only send the NewIdentity to client itself.
						guestMessage(guest.guestId, response.toString());
						response = JSONTools.ServerMessage("#Server", newId + " is invalid.");
						guestMessage(guest.guestId, response.toString());
					}
					
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
					
	        		break;
	        	} // case "identitychange" ends.
	        	
	        	case "join": {
	        		String roomId = command.getString("roomid");
	        		
                    if (isRightRoomid(roomId) && isRoomExist(roomId) && (!roomId.equals(guest.room))) {
                        // If the requested roomid is right, do:
                        if (!lookupBlacklist(guest, roomId)) {
                            // If the client is forbidden to join this room.
                            response = JSONTools.RoomChange(guest.guestId, guest.room, guest.room);
                            // Send response message only to the guest to tell it the forbidden information.
                            guestMessage(guest.guestId, response.toString());
                            response = JSONTools.ServerMessage("#Server", "You are forbidden to join " + roomId);
                            guestMessage(guest.guestId, response.toString());
                        } else {
                            // If the client is not forbidden and the room is valid.
                            if (roomId.equals("MainHall")) {
                                // If the guest wants to be moved to MainHall.
                                String formerRoom = guest.room;
                                guest.room = "MainHall";
                                // Generate a RoomChange message.
                                response = JSONTools.RoomChange(guest.guestId, formerRoom, roomId);
                                // Sent to former room and current room.
                                roomMessage(formerRoom, response.toString());
                                roomMessage(roomId, response.toString());
                                // RoomList, send to client itself.
                                CalcRoomList();
                                response = JSONTools.RoomList(roomList);
                                guestMessage(guest.guestId, response.toString());
                                // RoomContent, send to client itself.
                                response = JSONTools.RoomContents("MainHall", guestList);
                                guestMessage(guest.guestId, response.toString());
                                
                                System.out.println(guest.guestId + " moves from " + formerRoom + " to MainHall.");
                            } else {
                                // Move to other room.
                                String formerRoom = guest.room;
                                guest.room = roomId;
                                // Generate a RoomChange message.
                                response = JSONTools.RoomChange(guest.guestId, formerRoom, roomId);
                                // Sent to former room and current room;
                                roomMessage(formerRoom, response.toString());
                                roomMessage(roomId, response.toString());
                                System.out.println(guest.guestId + " moves from " + formerRoom + " to " + guest.room + ".");
                            } // Move room ends.
                        }

                    } else {
                    	
                        // If the requested roomid is false, then the former room equals the current room.
                        response = JSONTools.RoomChange(guest.guestId, guest.room, guest.room);
                        // Send response message only to the guest.
                        guestMessage(guest.guestId, response.toString());
                        
                    	if (!isRightRoomid(roomId)) {
                    		response = JSONTools.ServerMessage("#Server", "The room id " + roomId + " is invalid.");
                    		guestMessage(guest.guestId, response.toString());
                    	} else if (!isRoomExist(roomId)) {
                    		response = JSONTools.ServerMessage("#Server", "The room " + roomId + " is not exist.");
                    		guestMessage(guest.guestId, response.toString());
                    	} else if (roomId.equals(guest.room)) {
                    		response = JSONTools.ServerMessage("#Server", "You are already in this room.");
                    		guestMessage(guest.guestId, response.toString());
                    	} else {
                    		response = JSONTools.ServerMessage("#Server", "Request denied.");
                    		guestMessage(guest.guestId, response.toString());
                    	}

                    } // Room validity check ends
                    
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
                    
	        		break;
	        	} // case "join" ends.
	        	
	        	case "who": {
	        		String roomId = command.getString("roomid");
	        		// Check if the required room is exist.
	        		if (!isRoomExist(roomId)) {
	        			response = JSONTools.ServerMessage("#Server", roomId + " does not exist.");
	        			guestMessage(guest.guestId, response.toString());
	        		} else {
		        		response = JSONTools.RoomContents(roomId, guestList);
		        		guestMessage(guest.guestId, response.toString());
	        		}
	        		
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
	        		
	        		break; 
	        	} // case "who" ends.
	        	
	        	case "list": {
	        		CalcRoomList();
	        		response = JSONTools.RoomList(roomList);
	        		guestMessage(guest.guestId, response.toString());
	        		
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////

	        		break;
	        	} // case "list" ends.
	        	
	        	case "createroom": {
	        		String roomId = command.getString("roomid");

					if (isRightRoomid(roomId) && (!isRoomExist(roomId))) {
						// If the room id is valid and not exist.
						// Create the room.
						roomList.add(new Room(roomId, guest.guestId));
	
						// Tell the creator that the room is created.
						response = JSONTools.ServerMessage("#Server", "Room " + roomId + " is created successfully!");
						guestMessage(guest.guestId, response.toString());
	
						// Send a roomList to the creator.
						CalcRoomList();
						response = JSONTools.RoomList(roomList);
						guestMessage(guest.guestId, response.toString());
						
						System.out.println(guest.guestId + " creates a room: " + roomId + ".");
	
					} else {
						// If the room id is already exist.
						if (!isRightRoomid(roomId)) {
							response = JSONTools.ServerMessage("#Server", "Room name " + roomId + " is invalid!");
							guestMessage(guest.guestId, response.toString());
						} else if (isRoomExist(roomId)) {
							response = JSONTools.ServerMessage("#Server", "Room " + roomId + " is already exist!");
							guestMessage(guest.guestId, response.toString());
						} else {
							response = JSONTools.ServerMessage("#Server", "Creation fails!");
							guestMessage(guest.guestId, response.toString());
						}
					}
	        		
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
	        		
	        		break;
	        	} // case "createroom" ends.
	        	
	        	case "kick": {
	        		String kickedGuest = command.getString("identity");
	        		int forbiddenTime = command.getInt("time");
	        		String forbiddenRoom = command.getString("roomid");
	        		// The operation will be done only if 1. the kicked guest is in the room;
	        		// 2. The guest who kick others is the owner of this room; 3. The kicked guest is not the owner itself.
	        		if (isInRoom(kickedGuest, forbiddenRoom) && guestIsOwner(guest.guestId, forbiddenRoom) 
	        												 && (guest.guestId != kickedGuest) ) {
	        			// Search the whole guest list.
	        			for (Guest g : guestList) {
	        				if (g.guestId.equals(kickedGuest)) {
	        					// Move the guest to MainHall
	        					g.room = "MainHall";
	        					// Add the blacklist
	        					try {
									g.blacklist.add(new Blacklist(forbiddenRoom, forbiddenTime));
								} catch (ParseException e) {
									e.printStackTrace();
								}
	        					// Tell the kicked guest
	        					String kickMsg = "You are kicked from " + forbiddenRoom + " for " + forbiddenTime + " seconds.";
	        					response = JSONTools.ServerMessage("#Server", kickMsg);
	        					guestMessage(kickedGuest, response.toString());
	        					response = JSONTools.RoomChange(kickedGuest, forbiddenRoom, "MainHall");
	        					
	        					System.out.println(kickedGuest + " is kicked out from " + forbiddenRoom + ".");
	        				}
	        			}
	        			// Send the kick out message to all clients left in the room.
	        			response = JSONTools.ServerMessage("#Server", kickedGuest + " is kicked out.");
	        			roomMessage(forbiddenRoom, response.toString());
	        		} else {
	        			if (!isInRoom(kickedGuest, forbiddenRoom)) {
		        			response = JSONTools.ServerMessage("#Server", "Request denied! The guest is not in this room!");
		        			guestMessage(guest.guestId, response.toString());
	        			} else if (!guestIsOwner(guest.guestId, forbiddenRoom)) {
		        			response = JSONTools.ServerMessage("#Server", "Request denied! You are not the room owner!");
		        			guestMessage(guest.guestId, response.toString());
	        			} else {
		        			response = JSONTools.ServerMessage("#Server", "Request denied! You cannot kick yourself!");
		        			guestMessage(guest.guestId, response.toString());
	        			}
	        			// If the operation is unsuccessful, tell the client who send this command.
//	        			response = JSONTools.ServerMessage("#Server", "Request denied!");
//	        			guestMessage(guest.guestId, response.toString());
	        		}
	        		
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
	        		
	        		break;
	        	} // case "kick" ends.
	        	
	        	case "delete": {
	        		String deletedRoom = command.getString("roomid");
	        		// Check if the client is in deleted room and if it is owner.
	        		if (guestIsOwner(guest.guestId, deletedRoom)) {
	        			
	        			DeleteRoom(deletedRoom);
	        			
	        			// Move all clients to MainHall including the owner.
	        			for (Guest g : guestList) {
	        				if (g.room.equals(deletedRoom)) {
	        					g.room = "MainHall";
	        					response = JSONTools.RoomChange(g.guestId, deletedRoom, "MainHall");
	        					guestMessage(g.guestId, response.toString());
	        				}
	        			}
	        			
	        			// Send the ex-owner a room list.
	        			CalcRoomList();
		        		response = JSONTools.RoomList(roomList);
		        		guestMessage(guest.guestId, response.toString());
		        		
		        		System.out.println(guest.guestId + " deletes the room " + deletedRoom + ".");
	        		} else {
	        			// The situation that the room can not be deleted.
	        			response = JSONTools.RoomChange(guest.guestId, guest.room, guest.room);
	        			guestMessage(guest.guestId, response.toString());
	        		}
	        		
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
	        		
	        		break;
	        	} // case "delete" ends.
	        	
	        	case "quit": {
//	        		response = JSONTools.ServerMessage("#Server", guest.guestId + " leaves " + guest.room);
//	        		roomMessage(guest.room, response.toString());
	        		
	        		// Set the current room as null before quit.
	        		String room = guest.room;
	        		guest.room = "";
	        		
	        		if (guest.registered) {
						System.out.println("The regerested guest " + guest.guestId + " quits.");

						response = JSONTools.ServerMessage("#Server", "See you later, old friend!");
						guestMessage(guest.guestId, response.toString());
	        			response = JSONTools.ServerMessage("#Server", "Disconnected from server.");
		        		guestMessage(guest.guestId, response.toString());
	        		} else {
		        		// Release the guest's name.
						if (guest.guestId.contains("guest")) {
							// Release the number in the former identity, such as '1' in guest1.
							System.out.println("The temporary guest " + guest.guestId + " quits.");
							char a = guest.guestId.charAt(guest.guestId.length()-1);
							int idNum = Integer.parseInt(String.valueOf(a));
							guestName.remove((Integer)idNum);
						}
		        		
		        		// Tell all guests in the room that someone leaves.
		        		response = JSONTools.RoomChange(guest.guestId, room, "");
		        		roomMessage(room, response.toString());
		        		// If the client is owner, do something like the guest delete its room.
	        			if (guestIsOwner(guest.guestId, room)) {
	        				String ownerRoom = room;
	        				String ownerId = guest.guestId;

	        				DeleteRoom(ownerRoom);
	        				// Move all guests in the room to MainHall except the owner.
	        				// Because the owner will not be in MainHall anymore.
		        			for (Guest g : guestList) {
		        				if (g.room.equals(ownerRoom) && (!g.guestId.equals(ownerId))) {
		        					g.room = "MainHall";
		        					response = JSONTools.RoomChange(g.guestId, ownerRoom, "MainHall");
		        					guestMessage(g.guestId, response.toString());
		        				}
		        			}
	        			}
		        		// Send message to this client.
	        			response = JSONTools.ServerMessage("#Server", "Disconnected from server.");
		        		guestMessage(guest.guestId, response.toString());
	        		}
	        		

	        		break;
	        	} // case "quit" ends.
	        	
	        	case "message": {
	        		// Add sender's id to the raw message.
	        		response = JSONTools.ServerMessage(guest.guestId, command.getString("content"));
	        		// Send the message to sender's room.
	        		roomMessage(guest.room, response.toString());
	        		
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
	        		
	        		break;
	        	} // case "message" ends.
	        	
	        	default : {
	        		// If the client send a invalid message.
	        		response = JSONTools.ServerMessage("#Server", "Invalid command, please try again!");
	        		guestMessage(guest.guestId, response.toString());
	        		
					///////////////////////////////////////////////////////////////
					// Let the client print a message like "[MainHall] guest1> " //
					response = JSONTools.ServerMessage(">console", "[" + guest.room + "] " + guest.guestId + "> ");
					guestMessage(guest.guestId, response.toString());
					///////////////////////////////////////////////////////////////
					
	        	} // default ends.
        	}
        }
        
        
        // Send message to a guest. whose id is given.
        private void guestMessage(String client, String msg) {
            //System.out.println(msg);
            for (Guest guest : guestList) {
            	if (guest.guestId.equals(client)) {
            		try {
						printWriter = new PrintWriter(guest.socket.getOutputStream(), true);
					} catch (IOException e) {
						e.printStackTrace();
					}
            		printWriter.println(msg);
            	}
            }
        } 
        
        // Send message to a room whose id is given.
        private void roomMessage(String room, String msg) {
            //System.out.println(msg);
            for (Guest guest : guestList) {
            	if (guest.room.equals(room)) {
            		try {
						printWriter = new PrintWriter(guest.socket.getOutputStream(), true);
					} catch (IOException e) {
						e.printStackTrace();
					}
            		printWriter.println(msg);
            		
            	}
            }
        }

        // Send message to all clients connected to the server.
        private void overallMessage(String msg) {
            //System.out.println(msg);
            for (Guest guest : guestList) {
            	try {
					printWriter = new PrintWriter(guest.socket.getOutputStream(), true);
				} catch (IOException e) {
					e.printStackTrace();
				}
            	printWriter.println(msg);
            }
        }
        
        
    } // Thread ends.
    
    
    // Give the smallest unused guest name.
    public static String initialName() {
        int n = 0;
        for (int i=1;i<65535;i++) {
            if (!guestName.contains(i)) {
                n = i;
                break;
            }
        }
        guestName.add(n);
        return "guest" + n;
    }
    
    // Check if a username is valid. return true if it is valid, otherwise return false.
    public static boolean isValidId(String str) {
    	if ((str.length() >= 3) && (str.length() <=16)) {
    		boolean flag = true;
    		for (int i=0; i<str.length(); i++) {
    			if (Character.isLetterOrDigit(str.charAt(i))) {
    				flag = true;
    			} else {
    				flag = false;
    				break;
    			}
    		}
    		return flag;
    	}
		return false;
    }
    
    // Ckeck if a userid is used. If not used, return true, otherwise return false.
    public static boolean isNotInuse(String id) {
    	for (int i=0; i<guestList.size(); i++) {
    		if (id.equals(guestList.get(i).guestId)) {
    			//return guestList.get(i).formerId;
    			return false;
    		}
    	}
    	return true;
    }
    
    // Examine if the requested roomid is valid or exsist.
    public static boolean isRightRoomid(String roomid) {
    	if (!Character.isLetter(roomid.charAt(0))) {
    		return false;
    	}
    	if ((roomid.length() >= 3) && (roomid.length() <=32)) {
    		boolean flag = true;
    		for (int i=0; i<roomid.length(); i++) {
    			if (Character.isLetterOrDigit(roomid.charAt(i))) {
    				flag = true;
    			} else {
    				flag = false;
    				break;
    			}
    		}
    		return flag;
    	}
		return false;
    }
    
    // Check whether a room is exist.
    public static boolean isRoomExist(String roomid) {
    	for (Room room : roomList) {
    		if (room.roomId.equals(roomid)) {
    			return true;
    		}
    	}
    	return false;
    }

    // Return true if the guest can join the room, otherwise return false.
    public static boolean lookupBlacklist(Guest guest1, String roomid) {
    	ArrayList<Blacklist> bl = guest1.blacklist;
    	if (bl.size() == 0) {
    		return true;
    	} else {
	    	for (Blacklist bl1 : bl) {
	    		if (bl1.forbiddenRoom.equals(roomid)) {
	    			try {
						if (Time.getCurrentTime() < bl1.forbiddenTime) {
							return false;
						}
					} catch (ParseException e) {
						e.printStackTrace();
					}
	    		}
	    	}
    	}
    	return true;
    }
    
    // Look if one guest is in the given room.
    public static boolean isInRoom(String guest, String room) {
    	for (Guest g : guestList) {
    		if (g.guestId.equals(guest) && g.room.equals(room)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    // Get the roomlist by searching in the guestList.
    public static void CalcRoomList () {
    	for(Room r : roomList) {
    		r.guestList.clear();
    	}
    	for(Room r : roomList) {
    		for (Guest g : guestList) {
    			if (g.room.equals(r.roomId)) {
    				r.guestList.add(g.guestId);
    			}
    		}
    	}
    }
    
	
    public static void DeleteGuestsRoom(String guestId) {
    	for (Room r : roomList) {
    		if (r.ownerId.equals(guestId)) {
    			roomList.remove(r);
    		}
    	}
    }
    

    public static void DeleteRoom(String roomId) {
    	int index = 65535;
    	for (int i=0; i<roomList.size(); i++) {
    		if (roomList.get(i).roomId.equals(roomId))
    			index = i;
    	}
    	if (index != 65535) {
    		roomList.remove(index);
    	}
    }
    
    
    public static boolean guestIsOwner(String g, String r) {
    	for (Room room : roomList) {
    		if (room.roomId.equals(r) && room.ownerId.equals(g))
    			return true;
    	}
    	return false;
    }
	
    public static boolean isRegistedId(String Id) {
    	for (AuthenticatedGuest a : registeredList) {
    		if (a.guestId.equals(Id)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    public static boolean checkAuthentication(String username, String password) {
    	for (AuthenticatedGuest a : registeredList) {
    		try {
				if (a.getUsername().equals(username) && a.getPassword().equals(password)) {
					return true;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	return false;
    }
    
    public static String getAuthenticatedId(String username) {
    	String id = "";
    	for (AuthenticatedGuest a : registeredList) {
    		try {
				if (a.getUsername().equals(username)) {
					id = a.guestId;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	return id;
    }
    
    
    public static void setAuthenticatedId(String username, String id) {
    	for (AuthenticatedGuest a : registeredList) {
    		try {
				if (a.getUsername().equals(username)) {
					a.guestId = id;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
    }
    
    
    public static void changeAuthenticatedId(String guestId, String newId) {
    	for (AuthenticatedGuest a : registeredList) {
    		if (a.guestId.equals(guestId)) {
    			a.guestId = newId;
    		}
    	}
    }
    
    
    public static void addAuthentication(String username, String password, String guestId) {
    	registeredList.add(new AuthenticatedGuest(guestId, username, password));
    }
	
}


