package com.ds.proj2;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Time {
	public static long getCurrentTime() throws ParseException {
		SimpleDateFormat dfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date now = dfs.parse(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss") .format(new Date() ));
		return now.getTime()/1000;
	}
}
