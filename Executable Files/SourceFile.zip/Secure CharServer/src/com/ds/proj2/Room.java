package com.ds.proj2;
import java.util.ArrayList;

public class Room {
	public String roomId;
	public String ownerId;
	public ArrayList<String> guestList = new ArrayList<>();
	
	public Room() {}
	
	public Room(String id, String owner) {
		this.roomId = id;
		this.ownerId = owner;
	}
	
}
