package com.ds.proj2;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JSONTools {
	
	public static JSONObject StrToObj(String jsonStr) throws JSONException {
		JSONObject jsonobj = new JSONObject(jsonStr);
		return jsonobj;		
	}
	
	public static JSONObject NewIdentity (String formerid, String newid) throws JSONException {
		JSONObject obj = new JSONObject();
		obj.put("type", "newidentity");
		obj.put("former", formerid);
		obj.put("identity", newid);
		return obj;
	}
	
	public static JSONObject RoomContents (String roomid, ArrayList<Guest> guests) throws JSONException{
		JSONObject obj = new JSONObject();
		obj.put("type", "roomcontents");
		obj.put("roomid", roomid);
		String owner = "";
		JSONArray array = new JSONArray();
		for (Guest g : guests) {
			if (g.room.equals(roomid)) {
				array.put(g.guestId);
				if (SSLchatserver.guestIsOwner(g.guestId, roomid)) {
					owner = g.guestId;
				}
			}
		}
		obj.put("identities", array);
		obj.put("owner", owner);
		return obj;
	}
	
	public static JSONObject RoomChange (String guest, String former, String roomid) throws JSONException{
		JSONObject obj = new JSONObject();
		obj.put("type", "roomchange");
		obj.put("identity", guest);
		obj.put("former", former);
		obj.put("roomid", roomid);
		return obj;
	}
	
	public static JSONObject RoomList (ArrayList<Room> rooms) throws JSONException{
		JSONObject obj = new JSONObject();
		obj.put("type", "roomlist");
		JSONArray roomList = new JSONArray();
		for (int i=0; i<rooms.size(); i++) {
			JSONObject room = new JSONObject();
			room.put("roomid", rooms.get(i).roomId);
			room.put("count", rooms.get(i).guestList.size());
			roomList.put(room);
		}
		obj.put("rooms", roomList);
		return obj;
	}
	
	public static JSONObject ServerMessage (String guest, String msg) throws JSONException{
		JSONObject obj = new JSONObject();
		obj.put("type", "message");
		obj.put("identity", guest);
		obj.put("content", msg);
		return obj;
	}

	
}
