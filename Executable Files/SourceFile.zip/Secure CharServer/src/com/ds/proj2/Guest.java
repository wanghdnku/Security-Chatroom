package com.ds.proj2;
import java.net.Socket;
import java.util.ArrayList;

public class Guest {
	public String guestId;
	public String formerId;
	public Socket socket = new Socket(); 
	
	public boolean registered = false;
	
	
	// 所在的房间
	public String room = "MainHall";	
	
	//public boolean ownership = false;
	public ArrayList<Blacklist> blacklist = new ArrayList<>();
	
	public Guest() {
	};

	public Guest(String id, String former, Socket s) {
		this.guestId = id;
		this.formerId = former;
		this.socket = s;
	}
	
	public void createRoom (String room) {
		
	}
	
}
