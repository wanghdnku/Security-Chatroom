package com.ds.proj2;
import java.text.ParseException;

public class Blacklist {
	public String forbiddenRoom;
	public long forbiddenTime;
	
	public Blacklist() {};
	public Blacklist(String roomid, long time) throws ParseException {
		this.forbiddenRoom = roomid;
		this.forbiddenTime = time + Time.getCurrentTime();
	}
	
	public void setForbiddenId(String id) {
		this.forbiddenRoom = id;
	}
	public void setForbiddenTime(long time) throws ParseException {
		this.forbiddenTime = time + Time.getCurrentTime();
	}
	public String getForbiddenId() {
		return forbiddenRoom;
	}
	public long getForbiddenTime() {
		return forbiddenTime;
	}
}
