package com.ds.proj2;
import org.kohsuke.args4j.*;

public class ServerCmdLine {
	
	// Give it a default value of 4444 sec
	@Option(required = false, name = "-p", aliases = {"--port"}, usage="Port Address")
	private int port = 4444;
	
	@Option(required = true, name = "-keystore", aliases = {"--keystore"}, usage = "Keystore Path")
	private String certPath;
	
	@Option(required = false, name = "-storepass", aliases = {"--password"}, usage = "Keystore Password")
	private String password = "comp90015";
	
	@Option(required = false, name = "-keypass", aliases = {"--privatekey"}, usage = "Privatekey Password")
	private String keypass = "123456";
	

	public String getStorePass() {
		return password;
	}
	
	public String getKeyPass() {
		return keypass;
	}
	
	public String getPath() {
		return certPath;
	}
	
	public int getPort() {
		return port;
	}
	
}
