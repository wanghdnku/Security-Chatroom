package com.ds.proj2;
import java.security.Key;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class AuthenticatedGuest {
	private String username;
	private String password;
	public String guestId;
	private byte[] salt;
	private Key key;
	
	
	public AuthenticatedGuest(String guestId) {
		this.guestId = guestId;
		SecureRandom random = new SecureRandom();
		this.salt = random.generateSeed(8);
		PBEKeySpec pbeKeySpec = new PBEKeySpec(guestId.toCharArray());
		SecretKeyFactory factory;
		try {
			factory = SecretKeyFactory.getInstance("PBEWITHMD5andDES");
			this.key = factory.generateSecret(pbeKeySpec);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public AuthenticatedGuest(String guestId, String username, String password) {
		this.guestId = guestId;
		SecureRandom random = new SecureRandom();
		this.salt = random.generateSeed(8);
		PBEKeySpec pbeKeySpec = new PBEKeySpec(guestId.toCharArray());
		SecretKeyFactory factory;
		try {
			factory = SecretKeyFactory.getInstance("PBEWITHMD5andDES");
			this.key = factory.generateSecret(pbeKeySpec);

			String encodedUn = ServerSecurity.pbeEncoder(username, salt, key);
			this.username = encodedUn;
			String encodedPw = ServerSecurity.pbeEncoder(password, salt, key);
			this.password = encodedPw;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
	public void setGuestId(String id) {
		this.guestId = id;
	}
	
	public String getGuestId() {
		return this.guestId;
	}
	
	
	public void setUsername(String plainUn) {
		try {
			String encodedUn = ServerSecurity.pbeEncoder(plainUn, salt, key);
			this.username = encodedUn;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setPassword(String plainPw) {
		try {
			String encodedPw = ServerSecurity.pbeEncoder(plainPw, salt, key);
			this.password = encodedPw;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getUsername() throws Exception {
		String plainUn = ServerSecurity.pbeDecoder(username, salt, key);
		return plainUn;
	}
	
	public String getPassword() throws Exception {
		String plainPw = ServerSecurity.pbeDecoder(password, salt, key);
		return plainPw;
	}
	
}
